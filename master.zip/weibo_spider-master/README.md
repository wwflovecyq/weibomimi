# weibo_spider
爬取微博内评论。将评论内容和图片进行存储。


公众号文章地址： https://mp.weixin.qq.com/s/gyZ1o-ltvvf9uqFZIGIRJQ


欢迎关注我的公众号：Python3X 「微信搜索 python3xxx」

##### 一个专门面向Python程序员的社区。主要分享Python类技术干货，包括不限于Python技术、Web开发、爬虫、数据分析等，当然还有不定期的工具干货分享。另外次条都会推送 **[Python Every Day]** 系列,每天一道Python练习题。墙裂推荐学习Python的小伙伴，关注一波。

![Image text](https://github.com/python3xxx/weibo_spider/blob/master/wechat_qrcode/python3x_qrcode.jpg)
